package com.example.apigateway.checklist_service.repository;

public class ChecklistTemplateRepository {

}
