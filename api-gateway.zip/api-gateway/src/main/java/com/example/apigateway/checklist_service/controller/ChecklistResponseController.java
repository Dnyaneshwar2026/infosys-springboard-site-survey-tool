package com.example.apigateway.checklist_service.controller;

public class ChecklistResponseController {

}
