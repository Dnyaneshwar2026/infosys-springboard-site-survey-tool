package com.example.apigateway.checklist_service.dto;

public class ChecklistTemplateRequest {

}
