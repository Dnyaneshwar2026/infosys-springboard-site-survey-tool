package com.example.apigateway.checklist_service;

public class ChecklistApplication {

}
