package com.example.apigateway.checklist_service.service;

public class ChecklistTemplateService {

}
