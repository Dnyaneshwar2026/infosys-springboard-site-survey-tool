package com.example.apigateway.checklist_service.controller;

import com.example.apigateway.checklist_service.dto.ChecklistTemplateRequest;
import com.example.apigateway.checklist_service.entity.ChecklistTemplate;
import com.example.apigateway.checklist_service.service.ChecklistTemplateService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/templates")
@RequiredArgsConstructor
public class ChecklistTemplateController {

    private final ChecklistTemplateService service = new ChecklistTemplateService();

    @PostMapping
    public ChecklistTemplate create(@RequestBody ChecklistTemplateRequest req) {
        return service.create(req);
    }

    @GetMapping("/{id}")
    public ChecklistTemplate get(@PathVariable Long id) {
        return service.get(id);
    }
}
