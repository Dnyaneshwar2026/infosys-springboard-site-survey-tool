package com.example.apigateway.checklist_service.entity;

public class ChecklistResponse {

}
